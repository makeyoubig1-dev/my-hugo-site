---
title: "Hugo v0.99.1"
description: ""
date: 2022-05-18
draft: false
images: ["hugo-logo.png"]
categories: ["Hugo Release Notes"]
tags: ["Hugo"]
keywords: ["hugo v0.99"]
authors: ["Bjørn Erik Pedersen"]
aliases:
  - post/hugo-0-99-1
---

![Hugo](hugo-logo.svg)
{ .img-fluid .mb-5 }

Fix server regression for multihost sites (multiple languages with different baseURLs).

[Release Notes on GitHub](https://github.com/gohugoio/hugo/releases).
